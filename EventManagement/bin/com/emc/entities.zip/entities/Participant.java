package com.emc.entities;

public class Participant {
	public long id;
	public String name;
	public String email;
	public String checkdIn;
}
