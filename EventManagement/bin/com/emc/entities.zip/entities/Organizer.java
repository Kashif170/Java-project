package com.emc.entities;

public class Organizer {
public long id;
public String name;
}
