package com.emc.entities;

public class Venue {
	public long id;
	public String name;
	public String description;
	public String streetAdress;
	public String city;
	public String state;
	public String pincode;
}
